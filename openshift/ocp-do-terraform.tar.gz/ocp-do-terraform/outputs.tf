output "api_lb_ip" {
  description = "IP of the API load balancer — set api. and api-int. DNS records to this"
  value       = module.loadbalancer.api_lb_ip
}

output "ingress_lb_ip" {
  description = "IP of the Ingress load balancer — set *.apps. DNS record to this"
  value       = module.loadbalancer.ingress_lb_ip
}

output "bootstrap_ip" {
  description = "Bootstrap node public IP — SSH target for debugging"
  value       = module.compute.bootstrap_ip
}

output "master_ips" {
  description = "Control plane node IPs"
  value       = module.compute.master_ips
}

output "worker_ips" {
  description = "Worker node IPs"
  value       = module.compute.worker_ips
}

output "bootstrap_ignition_url" {
  description = "Presigned URL to bootstrap ignition (hosted in DO Spaces)"
  value       = module.storage.bootstrap_ignition_url
  sensitive   = true
}

output "console_url" {
  description = "OpenShift web console URL (available after install completes)"
  value       = "https://console-openshift-console.apps.${var.cluster_name}.${var.base_domain}"
}

output "api_url" {
  description = "OpenShift API endpoint"
  value       = "https://api.${var.cluster_name}.${var.base_domain}:6443"
}

output "next_steps" {
  description = "What to do after terraform apply"
  value       = <<-EOT

    ── NEXT STEPS ─────────────────────────────────────────────────────────────

    1. Monitor bootstrap:
       openshift-install wait-for bootstrap-complete --dir=./ignition --log-level=info

    2. Once bootstrap completes, approve worker CSRs:
       export KUBECONFIG=./ignition/auth/kubeconfig
       oc get csr
       oc get csr -o name | xargs oc adm certificate approve
       # Run twice — once for bootstrap CSR, once for serving CSR

    3. Wait for install to complete:
       openshift-install wait-for install-complete --dir=./ignition

    4. DESTROY the bootstrap node (save cost):
       terraform apply -var-file=terraform.tfvars -target=module.compute.digitalocean_droplet.bootstrap -destroy

    5. Check all operators healthy:
       oc get clusteroperators

    ───────────────────────────────────────────────────────────────────────────
  EOT
}
