variable "cluster_name" { type = string }
variable "region"       { type = string }
variable "vpc_uuid"     { type = string }

output "api_lb_ip"      { value = digitalocean_loadbalancer.api.ip }
output "api_lb_uuid"    { value = digitalocean_loadbalancer.api.id }
output "ingress_lb_ip"  { value = digitalocean_loadbalancer.ingress.ip }
output "ingress_lb_uuid" { value = digitalocean_loadbalancer.ingress.id }
