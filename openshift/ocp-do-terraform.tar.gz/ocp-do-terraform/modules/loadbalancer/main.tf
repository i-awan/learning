# ── API Load Balancer ─────────────────────────────────────────────────────────
# Handles:
#   :6443  — Kubernetes API server
#   :22623 — Machine Config Server (used during bootstrap for ignition delivery)
resource "digitalocean_loadbalancer" "api" {
  name     = "${var.cluster_name}-api"
  region   = var.region
  vpc_uuid = var.vpc_uuid

  # Use tag-based backend assignment — masters and bootstrap get ocp-api tag
  droplet_tag = "${var.cluster_name}-api"

  forwarding_rule {
    entry_protocol  = "tcp"
    entry_port      = 6443
    target_protocol = "tcp"
    target_port     = 6443
  }

  forwarding_rule {
    entry_protocol  = "tcp"
    entry_port      = 22623
    target_protocol = "tcp"
    target_port     = 22623
  }

  healthcheck {
    protocol               = "https"
    port                   = 6443
    path                   = "/readyz"
    check_interval_seconds = 10
    response_timeout_seconds = 5
    unhealthy_threshold    = 3
    healthy_threshold      = 2
  }

  # Sticky sessions not needed for API LB
  sticky_sessions {
    type = "none"
  }
}

# ── Ingress Load Balancer ─────────────────────────────────────────────────────
# Handles:
#   :80   — HTTP workload traffic → OpenShift Router
#   :443  — HTTPS workload traffic → OpenShift Router
resource "digitalocean_loadbalancer" "ingress" {
  name     = "${var.cluster_name}-ingress"
  region   = var.region
  vpc_uuid = var.vpc_uuid

  # Workers get ocp-ingress tag
  droplet_tag = "${var.cluster_name}-ingress"

  forwarding_rule {
    entry_protocol  = "tcp"
    entry_port      = 80
    target_protocol = "tcp"
    target_port     = 80
  }

  forwarding_rule {
    entry_protocol  = "tcp"
    entry_port      = 443
    target_protocol = "tcp"
    target_port     = 443
  }

  healthcheck {
    protocol               = "http"
    port                   = 1936       # HAProxy stats port on OpenShift Router
    path                   = "/healthz"
    check_interval_seconds = 10
    response_timeout_seconds = 5
    unhealthy_threshold    = 3
    healthy_threshold      = 2
  }

  sticky_sessions {
    type               = "cookies"
    cookie_name        = "DO-LB"
    cookie_ttl_seconds = 300
  }
}
