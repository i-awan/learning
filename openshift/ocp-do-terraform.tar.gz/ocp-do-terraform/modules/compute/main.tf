# ── Tags ─────────────────────────────────────────────────────────────────────
# DO LBs use tags to discover backends — critical to get right

resource "digitalocean_tag" "api" {
  name = "${var.cluster_name}-api"
}

resource "digitalocean_tag" "ingress" {
  name = "${var.cluster_name}-ingress"
}

resource "digitalocean_tag" "bootstrap" {
  name = "${var.cluster_name}-bootstrap"
}

resource "digitalocean_tag" "master" {
  name = "${var.cluster_name}-master"
}

resource "digitalocean_tag" "worker" {
  name = "${var.cluster_name}-worker"
}

# ── Bootstrap Node ────────────────────────────────────────────────────────────
# Temporary — runs the cluster bootstrap process then is destroyed.
# It needs the API LB tag so the MCS port (22623) is reachable by masters
# during bootstrap.
#
# Bootstrap ignition is too large for user-data directly (~300KB).
# We pass a pointer config that tells RHCOS to fetch the real ignition
# from DO Spaces.
resource "digitalocean_droplet" "bootstrap" {
  name      = "${var.cluster_name}-bootstrap"
  region    = var.region
  size      = var.master_size   # bootstrap needs same resources as masters
  image     = var.rhcos_image_id
  vpc_uuid  = var.vpc_uuid
  ssh_keys  = [var.ssh_fingerprint]

  tags = [
    digitalocean_tag.bootstrap.name,
    digitalocean_tag.api.name,   # Must be behind API LB for port 22623
  ]

  # RHCOS ignition pointer — tells bootstrap node to fetch full ignition from Spaces
  user_data = jsonencode({
    ignition = {
      version = "3.1.0"
      config = {
        replace = {
          source = var.bootstrap_ignition_url
        }
      }
    }
  })
}

# ── Control Plane Nodes ───────────────────────────────────────────────────────
# 3 masters — etcd needs odd numbers (quorum).
# These are permanent and should NOT be destroyed after install.
resource "digitalocean_droplet" "master" {
  count = 3

  name     = "${var.cluster_name}-master-${count.index + 1}"
  region   = var.region
  size     = var.master_size
  image    = var.rhcos_image_id
  vpc_uuid = var.vpc_uuid
  ssh_keys = [var.ssh_fingerprint]

  tags = [
    digitalocean_tag.master.name,
    digitalocean_tag.api.name,   # Behind API LB
  ]

  # Master ignition is small enough for user-data
  user_data = var.master_ignition
}

# ── Worker Nodes ──────────────────────────────────────────────────────────────
resource "digitalocean_droplet" "worker" {
  count = var.worker_count

  name     = "${var.cluster_name}-worker-${count.index + 1}"
  region   = var.region
  size     = var.worker_size
  image    = var.rhcos_image_id
  vpc_uuid = var.vpc_uuid
  ssh_keys = [var.ssh_fingerprint]

  tags = [
    digitalocean_tag.worker.name,
    digitalocean_tag.ingress.name,  # Behind Ingress LB
  ]

  user_data = var.worker_ignition
}

# ── Firewall ──────────────────────────────────────────────────────────────────
resource "digitalocean_firewall" "ocp" {
  name = "${var.cluster_name}-firewall"

  tags = [
    digitalocean_tag.master.name,
    digitalocean_tag.worker.name,
    digitalocean_tag.bootstrap.name,
  ]

  # SSH — restrict to your IP in production; open here for lab convenience
  inbound_rule {
    protocol         = "tcp"
    port_range       = "22"
    source_addresses = ["0.0.0.0/0", "::/0"]
  }

  # Kubernetes API
  inbound_rule {
    protocol         = "tcp"
    port_range       = "6443"
    source_addresses = ["0.0.0.0/0", "::/0"]
  }

  # Machine Config Server (bootstrap → masters only, but allow all for simplicity)
  inbound_rule {
    protocol         = "tcp"
    port_range       = "22623"
    source_addresses = ["0.0.0.0/0", "::/0"]
  }

  # HTTP/HTTPS for ingress
  inbound_rule {
    protocol         = "tcp"
    port_range       = "80"
    source_addresses = ["0.0.0.0/0", "::/0"]
  }

  inbound_rule {
    protocol         = "tcp"
    port_range       = "443"
    source_addresses = ["0.0.0.0/0", "::/0"]
  }

  # Internal cluster traffic — all ports within VPC
  inbound_rule {
    protocol         = "tcp"
    port_range       = "all"
    source_tags      = [
      digitalocean_tag.master.name,
      digitalocean_tag.worker.name,
      digitalocean_tag.bootstrap.name,
    ]
  }

  inbound_rule {
    protocol         = "udp"
    port_range       = "all"
    source_tags      = [
      digitalocean_tag.master.name,
      digitalocean_tag.worker.name,
      digitalocean_tag.bootstrap.name,
    ]
  }

  # HAProxy stats port — needed for ingress LB health check
  inbound_rule {
    protocol         = "tcp"
    port_range       = "1936"
    source_addresses = ["0.0.0.0/0", "::/0"]
  }

  # All outbound allowed
  outbound_rule {
    protocol              = "tcp"
    port_range            = "all"
    destination_addresses = ["0.0.0.0/0", "::/0"]
  }

  outbound_rule {
    protocol              = "udp"
    port_range            = "all"
    destination_addresses = ["0.0.0.0/0", "::/0"]
  }

  outbound_rule {
    protocol              = "icmp"
    destination_addresses = ["0.0.0.0/0", "::/0"]
  }
}
