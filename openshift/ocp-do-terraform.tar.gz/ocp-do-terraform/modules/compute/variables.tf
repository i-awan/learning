variable "cluster_name"           { type = string }
variable "region"                 { type = string }
variable "vpc_uuid"               { type = string }
variable "rhcos_image_id"         { type = string }
variable "ssh_fingerprint"        { type = string }
variable "bootstrap_ignition_url" { type = string }
variable "master_ignition"        { type = string }
variable "worker_ignition"        { type = string }
variable "master_size"            { type = string }
variable "worker_size"            { type = string }
variable "worker_count"           { type = number }
variable "api_lb_uuid"            { type = string }
variable "ingress_lb_uuid"        { type = string }

output "bootstrap_ip" {
  value = digitalocean_droplet.bootstrap.ipv4_address
}

output "master_ips" {
  value = digitalocean_droplet.master[*].ipv4_address
}

output "worker_ips" {
  value = digitalocean_droplet.worker[*].ipv4_address
}

output "bootstrap_droplet_id" {
  value = digitalocean_droplet.bootstrap.id
}
