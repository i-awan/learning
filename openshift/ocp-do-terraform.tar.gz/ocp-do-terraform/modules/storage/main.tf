terraform {
  required_providers {
    digitalocean = {
      source  = "digitalocean/digitalocean"
      version = "~> 2.34"
    }
  }
}

# DO Spaces bucket to host the bootstrap ignition file.
# Bootstrap.ign is too large for cloud-init user-data (~300KB), so we host
# it in object storage and pass a URL pointer in user-data instead.
resource "digitalocean_spaces_bucket" "ignition" {
  name   = "${var.cluster_name}-ignition-${random_id.suffix.hex}"
  region = var.region
  acl    = "private"

  lifecycle_rule {
    enabled = true
    expiration {
      days = 2 # ignition configs expire after 24h anyway
    }
  }
}

resource "random_id" "suffix" {
  byte_length = 4
}

# Upload bootstrap ignition
resource "digitalocean_spaces_bucket_object" "bootstrap_ign" {
  region       = digitalocean_spaces_bucket.ignition.region
  bucket       = digitalocean_spaces_bucket.ignition.name
  key          = "bootstrap.ign"
  source       = "${var.ignition_dir}/bootstrap.ign"
  content_type = "application/json"
  acl          = "private"

  # Force re-upload if file changes
  etag = filemd5("${var.ignition_dir}/bootstrap.ign")
}

# Generate a presigned URL valid for 24 hours
# Note: DO Spaces is S3-compatible so we use the AWS provider's presign approach
# via a null_resource + doctl, or construct it manually.
# Simplest approach: make the object temporarily public during bootstrap,
# then use a lifecycle rule to delete it.
# For production: use a presigned URL generator.

# For this practice setup, we make bootstrap.ign public for the install window.
# Rotate/delete after install completes.
resource "digitalocean_spaces_bucket_object" "bootstrap_ign_public" {
  region       = digitalocean_spaces_bucket.ignition.region
  bucket       = digitalocean_spaces_bucket.ignition.name
  key          = "bootstrap.ign"
  source       = "${var.ignition_dir}/bootstrap.ign"
  content_type = "application/json"
  acl          = "public-read"    # Temporarily public during install

  etag = filemd5("${var.ignition_dir}/bootstrap.ign")
}
