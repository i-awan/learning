variable "cluster_name"      { type = string }
variable "region"            { type = string }
variable "spaces_access_id"  { type = string; sensitive = true }
variable "spaces_secret_key" { type = string; sensitive = true }
variable "ignition_dir"      { type = string }

terraform {
  required_providers {
    random = {
      source  = "hashicorp/random"
      version = "~> 3.5"
    }
  }
}

output "bootstrap_ignition_url" {
  description = "Public URL to the bootstrap ignition file in DO Spaces"
  value       = "https://${digitalocean_spaces_bucket.ignition.name}.${var.region}.digitaloceanspaces.com/bootstrap.ign"
}

output "bucket_name" {
  value = digitalocean_spaces_bucket.ignition.name
}
