# Expects the base_domain to already exist as a DO-managed domain.
# If not yet added: doctl compute domain create example.com
#
# Records created:
#   api.<cluster>.<base>       → API LB      (Kubernetes API)
#   api-int.<cluster>.<base>   → API LB      (internal cluster traffic)
#   *.apps.<cluster>.<base>    → Ingress LB  (all workload routes)

data "digitalocean_domain" "base" {
  name = var.base_domain
}

resource "digitalocean_record" "api" {
  domain = data.digitalocean_domain.base.id
  type   = "A"
  name   = "api.${var.cluster_name}"
  value  = var.api_lb_ip
  ttl    = 300
}

resource "digitalocean_record" "api_int" {
  domain = data.digitalocean_domain.base.id
  type   = "A"
  name   = "api-int.${var.cluster_name}"
  value  = var.api_lb_ip   # same LB — internal resolution
  ttl    = 300
}

resource "digitalocean_record" "apps_wildcard" {
  domain = data.digitalocean_domain.base.id
  type   = "A"
  name   = "*.apps.${var.cluster_name}"
  value  = var.ingress_lb_ip
  ttl    = 300
}
