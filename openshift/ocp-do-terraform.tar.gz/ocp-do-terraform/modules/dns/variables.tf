variable "cluster_name"  { type = string }
variable "base_domain"   { type = string }
variable "api_lb_ip"     { type = string }
variable "ingress_lb_ip" { type = string }

output "api_fqdn"     { value = "api.${var.cluster_name}.${var.base_domain}" }
output "apps_wildcard" { value = "*.apps.${var.cluster_name}.${var.base_domain}" }
