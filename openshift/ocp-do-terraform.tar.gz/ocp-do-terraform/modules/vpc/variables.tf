variable "cluster_name" { type = string }
variable "region"       { type = string }
variable "vpc_cidr"     { type = string }

output "vpc_uuid" { value = digitalocean_vpc.ocp.id }
output "vpc_cidr" { value = digitalocean_vpc.ocp.ip_range }
