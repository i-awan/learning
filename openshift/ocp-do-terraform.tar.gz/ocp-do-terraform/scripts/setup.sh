#!/usr/bin/env bash
# =============================================================================
# OCP UPI on DigitalOcean — Setup & Workflow Script
# Run steps manually or use as a reference for the install sequence
# =============================================================================

set -euo pipefail

OCP_VERSION="4.15.0"   # Set to your target OCP version
CLUSTER_NAME="ocp"
BASE_DOMAIN="example.com"
REGION="lon1"

# ── STEP 0: Install tooling ───────────────────────────────────────────────────

install_tools() {
  echo "==> Installing openshift-install and oc CLI"

  # Download openshift-install
  wget -q "https://mirror.openshift.com/pub/openshift-v4/clients/ocp/${OCP_VERSION}/openshift-install-linux.tar.gz"
  tar xzf openshift-install-linux.tar.gz
  sudo mv openshift-install /usr/local/bin/
  rm openshift-install-linux.tar.gz

  # Download oc CLI
  wget -q "https://mirror.openshift.com/pub/openshift-v4/clients/ocp/${OCP_VERSION}/openshift-client-linux.tar.gz"
  tar xzf openshift-client-linux.tar.gz
  sudo mv oc kubectl /usr/local/bin/
  rm openshift-client-linux.tar.gz

  openshift-install version
  oc version --client
}

# ── STEP 1: Upload RHCOS image to DO ─────────────────────────────────────────

upload_rhcos_image() {
  echo "==> Fetching RHCOS image URL for OCP ${OCP_VERSION}"

  # Get the RHCOS image URL from the openshift-install binary itself
  # This guarantees version compatibility
  RHCOS_URL=$(openshift-install coreos print-stream-json | \
    python3 -c "
import sys, json
data = json.load(sys.stdin)
artifacts = data['architectures']['x86_64']['artifacts']
print(artifacts['digitalocean']['formats']['qcow2.gz']['disk']['location'])
" 2>/dev/null || echo "")

  if [[ -z "$RHCOS_URL" ]]; then
    echo "Could not auto-detect RHCOS URL. Check:"
    echo "  https://mirror.openshift.com/pub/openshift-v4/dependencies/rhcos/"
    echo "  Look for: rhcos-*-openstack.x86_64.qcow2.gz"
    exit 1
  fi

  echo "RHCOS URL: $RHCOS_URL"
  echo ""
  echo "Upload this image via DO console:"
  echo "  Manage → Images → Custom Images → Import from URL"
  echo "  Region: ${REGION}"
  echo "  Name: rhcos-${OCP_VERSION}"
  echo ""
  echo "Or via doctl:"
  echo "  doctl compute image create rhcos-${OCP_VERSION} \\"
  echo "    --region ${REGION} \\"
  echo "    --image-url '${RHCOS_URL}'"
  echo ""
  echo "After upload, get the image ID:"
  echo "  doctl compute image list --no-header | grep rhcos"
}

# ── STEP 2: Prepare install-config and generate ignition ─────────────────────

generate_ignition() {
  echo "==> Generating ignition configs"

  # Verify install-config.yaml.template has been filled out
  if grep -q '<REPLACE>' install-config.yaml.template; then
    echo "ERROR: Fill in all <REPLACE> values in install-config.yaml.template first"
    exit 1
  fi

  # Clean up any previous ignition run
  rm -rf ignition/
  mkdir ignition

  # Copy filled-in template (keep original as backup)
  cp install-config.yaml.template ignition/install-config.yaml

  # Generate manifests (review these before generating ignition)
  openshift-install create manifests --dir=ignition

  # Optional: prevent masters from being schedulable
  # Recommended for production, optional for lab
  sed -i 's/mastersSchedulable: true/mastersSchedulable: false/' \
    ignition/manifests/cluster-scheduler-02-config.yml

  # Generate ignition configs
  # WARNING: install-config.yaml is deleted by this step
  openshift-install create ignition-configs --dir=ignition

  echo ""
  echo "Generated files:"
  ls -lh ignition/*.ign ignition/auth/
  echo ""
  echo "WARNING: These expire in 24 hours. Run terraform apply now."
}

# ── STEP 3: Terraform ─────────────────────────────────────────────────────────

terraform_apply() {
  echo "==> Running terraform"

  # Copy tfvars if not already done
  if [[ ! -f terraform.tfvars ]]; then
    echo "ERROR: terraform.tfvars not found. Copy terraform.tfvars.example and fill in values."
    exit 1
  fi

  terraform init
  terraform plan -out=tfplan
  terraform apply tfplan
}

# ── STEP 4: Monitor bootstrap ─────────────────────────────────────────────────

wait_bootstrap() {
  echo "==> Waiting for bootstrap to complete (~20-40 min)"
  openshift-install wait-for bootstrap-complete \
    --dir=ignition \
    --log-level=info
}

# ── STEP 5: Approve worker CSRs ───────────────────────────────────────────────

approve_csrs() {
  export KUBECONFIG="$(pwd)/ignition/auth/kubeconfig"

  echo "==> Current nodes:"
  oc get nodes

  echo ""
  echo "==> Pending CSRs:"
  oc get csr

  echo ""
  read -p "Approve all pending CSRs? (y/N) " -n 1 -r
  echo
  if [[ $REPLY =~ ^[Yy]$ ]]; then
    oc get csr -o name | xargs oc adm certificate approve
    echo ""
    echo "Waiting 30s for serving CSRs to appear..."
    sleep 30
    oc get csr -o name | xargs oc adm certificate approve
    echo ""
    echo "==> Nodes after approval:"
    oc get nodes
  fi
}

# ── STEP 6: Wait for install complete ────────────────────────────────────────

wait_install() {
  echo "==> Waiting for install to complete"
  openshift-install wait-for install-complete --dir=ignition
}

# ── STEP 7: Destroy bootstrap (save money) ───────────────────────────────────

destroy_bootstrap() {
  echo "==> Destroying bootstrap node"
  terraform destroy \
    -target=module.compute.digitalocean_droplet.bootstrap \
    -var-file=terraform.tfvars \
    -auto-approve
  echo "Bootstrap destroyed. Remember to remove it from the API LB if needed."
}

# ── STEP 8: Verify cluster health ────────────────────────────────────────────

verify_cluster() {
  export KUBECONFIG="$(pwd)/ignition/auth/kubeconfig"

  echo "==> Cluster operators (wait for all Available=True, Degraded=False)"
  oc get clusteroperators

  echo ""
  echo "==> Nodes"
  oc get nodes

  echo ""
  echo "==> Cluster version"
  oc get clusterversion

  echo ""
  echo "Console: https://console-openshift-console.apps.${CLUSTER_NAME}.${BASE_DOMAIN}"
  echo "Password: $(cat ignition/auth/kubeadmin-password)"
}

# ── TEARDOWN: Full destroy ────────────────────────────────────────────────────

destroy_all() {
  echo "==> Destroying all infrastructure"
  read -p "This destroys everything. Are you sure? (yes/N) " confirm
  if [[ "$confirm" == "yes" ]]; then
    terraform destroy -var-file=terraform.tfvars -auto-approve
  fi
}

# ── Main menu ─────────────────────────────────────────────────────────────────

echo "OCP UPI on DigitalOcean"
echo "========================"
echo "Run functions manually in order:"
echo ""
echo "  1. install_tools"
echo "  2. upload_rhcos_image"
echo "  3. generate_ignition    # Do this immediately before terraform"
echo "  4. terraform_apply"
echo "  5. wait_bootstrap"
echo "  6. approve_csrs"
echo "  7. wait_install"
echo "  8. destroy_bootstrap"
echo "  9. verify_cluster"
echo ""
echo "  destroy_all             # Full teardown when done"
echo ""
echo "Source this file and call functions individually:"
echo "  source scripts/setup.sh"
