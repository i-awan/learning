variable "do_token" {
  description = "DigitalOcean API token"
  type        = string
  sensitive   = true
}

variable "spaces_access_id" {
  description = "DO Spaces access key ID (for ignition file hosting and optional remote state)"
  type        = string
  sensitive   = true
}

variable "spaces_secret_key" {
  description = "DO Spaces secret key"
  type        = string
  sensitive   = true
}

variable "cluster_name" {
  description = "OCP cluster name — becomes the subdomain prefix (e.g. 'ocp' → api.ocp.example.com)"
  type        = string
  default     = "ocp"
}

variable "base_domain" {
  description = "Base domain for the cluster. Must be managed in DO DNS."
  type        = string
  # e.g. "example.com"
}

variable "region" {
  description = "DO region slug"
  type        = string
  default     = "lon1"
}

variable "vpc_cidr" {
  description = "CIDR for the cluster VPC — must match machineNetwork in install-config.yaml"
  type        = string
  default     = "10.0.0.0/16"
}

variable "rhcos_image_id" {
  description = "ID of the RHCOS custom image uploaded to DO. Get via: doctl compute image list --public=false"
  type        = string
}

variable "ssh_fingerprint" {
  description = "MD5 fingerprint of the SSH key in your DO account. Get via: doctl compute ssh-key list"
  type        = string
}

variable "ignition_dir" {
  description = "Local path to the directory containing bootstrap.ign, master.ign, worker.ign"
  type        = string
  default     = "./ignition"
}

variable "master_size" {
  description = "Droplet size slug for control plane nodes (min 4 vCPU / 16GB)"
  type        = string
  default     = "s-4vcpu-16gb"
}

variable "worker_size" {
  description = "Droplet size slug for worker nodes (min 2 vCPU / 8GB)"
  type        = string
  default     = "s-2vcpu-8gb"
}

variable "worker_count" {
  description = "Number of worker nodes"
  type        = number
  default     = 2
}
