# OpenShift 4 UPI on DigitalOcean — Terraform

Practice lab for learning OpenShift UPI installation.
Not officially supported by Red Hat — for learning purposes.

## Prerequisites

| Tool | Purpose |
|---|---|
| `terraform` >= 1.5 | Infrastructure provisioning |
| `openshift-install` | Ignition config generation + install monitoring |
| `oc` | OpenShift CLI |
| `doctl` | DO CLI (image upload, verification) |

## Directory Structure

```
.
├── main.tf                       # Root module — wires everything together
├── variables.tf                  # All input variables
├── outputs.tf                    # Useful outputs + next steps
├── terraform.tfvars.example      # Copy to terraform.tfvars and fill in
├── install-config.yaml.template  # Fill in and use to generate ignition
├── .gitignore                    # Keeps secrets out of git
├── scripts/
│   └── setup.sh                  # Step-by-step workflow reference
└── modules/
    ├── vpc/          # VPC
    ├── storage/      # DO Spaces — hosts bootstrap.ign
    ├── loadbalancer/ # API LB (:6443, :22623) + Ingress LB (:80, :443)
    ├── dns/          # api., api-int., *.apps. DNS records
    └── compute/      # Bootstrap, master, worker droplets + firewall
```

## Quick Start

### 1. Prerequisites
```bash
# Install openshift-install and oc (see scripts/setup.sh → install_tools)
# Create a Red Hat account and download your pull secret from:
#   https://console.redhat.com → OpenShift → Downloads

# Authenticate doctl
doctl auth init
```

### 2. Upload RHCOS Image
```bash
# Get the correct RHCOS image URL for your OCP version
openshift-install coreos print-stream-json | python3 -c "
import sys, json
data = json.load(sys.stdin)
print(data['architectures']['x86_64']['artifacts']['digitalocean']['formats']['qcow2.gz']['disk']['location'])
"

# Upload via DO console: Manage → Images → Custom Images → Import from URL
# Or via doctl:
doctl compute image create rhcos-4.15 --region lon1 --image-url <URL>

# Get the image ID after upload
doctl compute image list --no-header | grep rhcos
```

### 3. Configure Terraform
```bash
cp terraform.tfvars.example terraform.tfvars
# Edit terraform.tfvars with your values

# Get your SSH key fingerprint
doctl compute ssh-key list
```

### 4. Generate Ignition Configs
```bash
# Fill in install-config.yaml.template → save as install-config.yaml
cp install-config.yaml.template install-config.yaml
# Edit install-config.yaml — fill in baseDomain, name, pullSecret, sshKey

mkdir ignition
cp install-config.yaml ignition/

openshift-install create manifests --dir=ignition

# Optional: prevent workloads on masters
sed -i 's/mastersSchedulable: true/mastersSchedulable: false/' \
  ignition/manifests/cluster-scheduler-02-config.yml

openshift-install create ignition-configs --dir=ignition
```
> **Do this immediately before `terraform apply` — ignition configs expire in 24 hours.**

### 5. Apply Terraform
```bash
terraform init
terraform plan
terraform apply
```

### 6. Monitor Bootstrap (~20-40 min)
```bash
openshift-install wait-for bootstrap-complete --dir=ignition --log-level=info
```

### 7. Approve Worker CSRs
```bash
export KUBECONFIG=$(pwd)/ignition/auth/kubeconfig
oc get csr
oc get csr -o name | xargs oc adm certificate approve
sleep 30
oc get csr -o name | xargs oc adm certificate approve  # Run twice
oc get nodes
```

### 8. Complete Install
```bash
openshift-install wait-for install-complete --dir=ignition
```

### 9. Destroy Bootstrap Node
```bash
terraform destroy \
  -target=module.compute.digitalocean_droplet.bootstrap \
  -var-file=terraform.tfvars
```

### 10. Verify
```bash
oc get clusteroperators   # All should be Available=True, Degraded=False
oc get nodes
```

## Cost Estimate

| Resource | Size | $/hr |
|---|---|---|
| Bootstrap (temporary) | s-4vcpu-16gb | ~$0.12 |
| Master × 3 | s-4vcpu-16gb | ~$0.36 |
| Worker × 2 | s-2vcpu-8gb | ~$0.12 |
| API Load Balancer | — | ~$0.015 |
| Ingress Load Balancer | — | ~$0.015 |
| DO Spaces | minimal | ~$0.00 |
| **Total (during install)** | | **~$0.63/hr** |
| **Total (post-install, no bootstrap)** | | **~$0.51/hr** |

Power off droplets when not in use. Delete when done practicing.

## Teardown
```bash
terraform destroy -var-file=terraform.tfvars
```

## Common Issues

| Symptom | Likely cause |
|---|---|
| Bootstrap never completes | `api.` DNS not resolving correctly |
| No CSRs appear | Worker user-data/ignition wrong, or port 22623 blocked |
| Operators degraded | Image registry needs storage configured |
| Console unreachable | `*.apps.` DNS not pointing to ingress LB |
| etcd unhealthy | Master nodes can't reach each other (VPC/firewall issue) |
