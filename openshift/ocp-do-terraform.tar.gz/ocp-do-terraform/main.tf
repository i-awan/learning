terraform {
  required_version = ">= 1.5.0"

  required_providers {
    digitalocean = {
      source  = "digitalocean/digitalocean"
      version = "~> 2.34"
    }
    local = {
      source  = "hashicorp/local"
      version = "~> 2.4"
    }
    null = {
      source  = "hashicorp/null"
      version = "~> 3.2"
    }
  }

  # Uncomment to use DO Spaces as remote state backend
  # backend "s3" {
  #   endpoint                    = "https://lon1.digitaloceanspaces.com"
  #   key                         = "ocp-upi/terraform.tfstate"
  #   bucket                      = "your-spaces-bucket"
  #   region                      = "us-east-1" # required by provider, value ignored
  #   skip_credentials_validation = true
  #   skip_metadata_api_check     = true
  #   skip_region_validation      = true
  #   force_path_style            = true
  # }
}

provider "digitalocean" {
  token             = var.do_token
  spaces_access_id  = var.spaces_access_id
  spaces_secret_key = var.spaces_secret_key
}

# ── VPC ───────────────────────────────────────────────────────────────────────
module "vpc" {
  source = "./modules/vpc"

  cluster_name = var.cluster_name
  region       = var.region
  vpc_cidr     = var.vpc_cidr
}

# ── Object Storage (Spaces) for ignition files ────────────────────────────────
module "storage" {
  source = "./modules/storage"

  cluster_name      = var.cluster_name
  region            = var.region
  spaces_access_id  = var.spaces_access_id
  spaces_secret_key = var.spaces_secret_key
  ignition_dir      = var.ignition_dir
}

# ── Load Balancers ────────────────────────────────────────────────────────────
module "loadbalancer" {
  source = "./modules/loadbalancer"

  cluster_name = var.cluster_name
  region       = var.region
  vpc_uuid     = module.vpc.vpc_uuid
}

# ── DNS ───────────────────────────────────────────────────────────────────────
module "dns" {
  source = "./modules/dns"

  cluster_name    = var.cluster_name
  base_domain     = var.base_domain
  api_lb_ip       = module.loadbalancer.api_lb_ip
  ingress_lb_ip   = module.loadbalancer.ingress_lb_ip
}

# ── Compute ───────────────────────────────────────────────────────────────────
module "compute" {
  source = "./modules/compute"

  cluster_name          = var.cluster_name
  region                = var.region
  vpc_uuid              = module.vpc.vpc_uuid
  rhcos_image_id        = var.rhcos_image_id
  ssh_fingerprint       = var.ssh_fingerprint
  bootstrap_ignition_url = module.storage.bootstrap_ignition_url
  master_ignition       = file("${var.ignition_dir}/master.ign")
  worker_ignition       = file("${var.ignition_dir}/worker.ign")
  master_size           = var.master_size
  worker_size           = var.worker_size
  worker_count          = var.worker_count
  api_lb_uuid           = module.loadbalancer.api_lb_uuid
  ingress_lb_uuid       = module.loadbalancer.ingress_lb_uuid
}
